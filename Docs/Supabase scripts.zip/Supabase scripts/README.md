# IT Helpdesk Ticketing System — Supabase Backend (Phase 3)

## Architecture
Flutter staff mobile app and ASP.NET Core MVC technician/manager web app connect independently to the same Supabase project. Shared records are stored in PostgreSQL; Supabase Auth supplies user identities. Database row-level security protects permitted operations.

## Confirmed implementation evidence
- Five tables: `profiles`, `tickets`, `ticket_status_history`, `comments`, `notifications`.
- `tickets` has UUID primary key; `reference_number`, title, description, category, priority, status, creator, assignee, optional resolution notes, and timestamps.
- Ticket status defaults to `Open`; priority defaults to `Medium`; resolution notes are nullable.
- `generate_ticket_reference()` uses `ticket_reference_seq` to generate `HD-000001`-style references.
- `record_ticket_status()` records initial and changed statuses in `ticket_status_history`.
- Five ticket triggers were observed: `trg_protect_ticket_fields`, `trg_ticket_reference`, `trg_ticket_status`, `trg_ticket_status_notification`, `trg_ticket_updated`.
- `tickets` RLS is enabled, with create-own, permitted-read, and technician/manager-update policies.
- The `authenticated` role was granted USAGE on `ticket_reference_seq` to address a missing privilege.

## Files
- `supabase/01_schema.sql`: reconstructed schema (partly unverified for non-ticket tables).
- `supabase/02_functions.sql`: two confirmed trigger function bodies.
- `supabase/03_triggers.sql`: confirmed trigger definitions for ticket INSERT/status history.
- `supabase/04_rls_policies.sql`: confirmed create-own policy; other observed policies are comments pending function export.
- `supabase/05_permissions.sql`: relevant grants.

## Important verification before final submission
These scripts are a **reconstruction from project conversations**, not a live database dump. Do not execute them on your working Supabase project. The exact schema of profiles, history, comments and notifications, foreign keys, additional function definitions, and non-ticket RLS policies must be compared against your live database. A clean installation is NOT guaranteed until those are exported.

For exact definitions, use Supabase's schema export/migrations tooling, or inspect the functions in SQL Editor with `pg_get_functiondef`. Never commit credentials, service-role keys, connection strings containing passwords, or real employee records.

## Two shared processes for demonstration
1. Staff logs in to Flutter and creates a ticket; the same reference appears in ASP.NET.
2. Technician/manager updates a ticket in ASP.NET; staff sees the updated status in Flutter after retrieval/refresh.

## Final ZIP layout
Place this `backend/` folder beside `mobile/` (Flutter), `web/` (ASP.NET Core MVC), and editable `designs/`. Ensure the ZIP and GitHub contain the same demonstrated version.
