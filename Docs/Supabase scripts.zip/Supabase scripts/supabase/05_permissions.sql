-- Confirmed permissions relevant to Flutter ticket creation.
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT INSERT ON TABLE public.tickets TO authenticated;
GRANT USAGE ON SEQUENCE public.ticket_reference_seq TO authenticated;
-- The live database may have other grants; export before production use.
