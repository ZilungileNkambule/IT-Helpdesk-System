-- Confirmed INSERT triggers. Run after 01_schema.sql and 02_functions.sql.
DROP TRIGGER IF EXISTS trg_ticket_reference ON public.tickets;
CREATE TRIGGER trg_ticket_reference BEFORE INSERT ON public.tickets
FOR EACH ROW EXECUTE FUNCTION public.generate_ticket_reference();
DROP TRIGGER IF EXISTS trg_ticket_status ON public.tickets;
CREATE TRIGGER trg_ticket_status AFTER INSERT OR UPDATE ON public.tickets
FOR EACH ROW EXECUTE FUNCTION public.record_ticket_status();

-- The following live triggers were observed but are NOT recreated here because
-- their exact function bodies have not been verified:
-- trg_protect_ticket_fields BEFORE UPDATE -> protect_ticket_fields()
-- trg_ticket_status_notification AFTER UPDATE OF status -> notify_ticket_status_change()
-- trg_ticket_updated BEFORE UPDATE -> update_ticket_timestamp()
