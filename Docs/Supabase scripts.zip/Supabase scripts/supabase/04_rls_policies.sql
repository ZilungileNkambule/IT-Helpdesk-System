-- Reconstructed policies from actual SQL Editor output.
-- Only tickets policies were confirmed; do not assume this is a complete security setup.
ALTER TABLE public.tickets ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Create own tickets" ON public.tickets;
CREATE POLICY "Create own tickets" ON public.tickets FOR INSERT TO authenticated
WITH CHECK (created_by = (SELECT auth.uid()) AND assigned_to IS NULL
 AND status = 'Open' AND resolution_notes IS NULL
 AND resolved_at IS NULL AND closed_at IS NULL);

-- The following SELECT and UPDATE policies depend on has_helpdesk_role(text[]),
-- whose definition has not been verified. Apply ONLY after exporting that function.
-- CREATE POLICY "Read permitted tickets" ON public.tickets FOR SELECT TO authenticated
-- USING (created_by = (SELECT auth.uid()) OR public.has_helpdesk_role(ARRAY['technician','manager']));
-- CREATE POLICY "Technicians and managers update tickets" ON public.tickets FOR UPDATE TO authenticated
-- USING (public.has_helpdesk_role(ARRAY['technician','manager']))
-- WITH CHECK (public.has_helpdesk_role(ARRAY['technician','manager']));

-- CRITICAL: This bundle does not recreate profiles/comments/notifications/history
-- policies. Do not deploy as a complete production RLS configuration.
