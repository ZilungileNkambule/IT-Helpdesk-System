-- Confirmed function bodies from our Supabase SQL Editor review.
CREATE OR REPLACE FUNCTION public.generate_ticket_reference()
RETURNS trigger LANGUAGE plpgsql SET search_path TO '' AS $function$
BEGIN
 IF NEW.reference_number IS NULL THEN
  NEW.reference_number := 'HD-' || LPAD(nextval('public.ticket_reference_seq')::TEXT, 6, '0');
 END IF;
 RETURN NEW;
END;
$function$;

CREATE OR REPLACE FUNCTION public.record_ticket_status()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO '' AS $function$
BEGIN
 IF TG_OP = 'INSERT' THEN
  INSERT INTO public.ticket_status_history(ticket_id, old_status, new_status, changed_by)
  VALUES (NEW.id, NULL, NEW.status, NEW.created_by);
 ELSIF NEW.status IS DISTINCT FROM OLD.status THEN
  INSERT INTO public.ticket_status_history(ticket_id, old_status, new_status, changed_by)
  VALUES (NEW.id, OLD.status, NEW.status, auth.uid());
 END IF;
 RETURN NEW;
END;
$function$;

-- The live database also contains these functions, but their definitions were
-- not provided: protect_ticket_fields(), notify_ticket_status_change(),
-- update_ticket_timestamp(), has_helpdesk_role(text[]).
-- Export their exact definitions before making a fully reproducible deployment.
