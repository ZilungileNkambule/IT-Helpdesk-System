-- IT Helpdesk Ticketing System: reconstructed demonstration schema.
-- REVIEW BEFORE USE. This is NOT an export of the live Supabase database.
-- Run only in a NEW, EMPTY project after verifying against your production schema.
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE SEQUENCE IF NOT EXISTS public.ticket_reference_seq START WITH 1 INCREMENT BY 1;

CREATE TABLE IF NOT EXISTS public.profiles (
 id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
 full_name text,
 email text,
 role text NOT NULL DEFAULT 'staff' CHECK (role IN ('staff','technician','manager')),
 is_active boolean NOT NULL DEFAULT true,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS public.tickets (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 reference_number text UNIQUE,
 title text NOT NULL,
 description text NOT NULL,
 category_id integer NOT NULL,
 priority text NOT NULL DEFAULT 'Medium',
 status text NOT NULL DEFAULT 'Open',
 created_by uuid NOT NULL REFERENCES public.profiles(id),
 assigned_to uuid REFERENCES public.profiles(id),
 resolution_notes text,
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(),
 resolved_at timestamptz,
 closed_at timestamptz
);
-- Columns below are plausible reconstructions, not verified live definitions.
CREATE TABLE IF NOT EXISTS public.ticket_status_history (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 ticket_id uuid NOT NULL REFERENCES public.tickets(id) ON DELETE CASCADE,
 old_status text,
 new_status text NOT NULL,
 changed_by uuid REFERENCES public.profiles(id),
 changed_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS public.comments (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 ticket_id uuid NOT NULL REFERENCES public.tickets(id) ON DELETE CASCADE,
 created_by uuid REFERENCES public.profiles(id),
 content text NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS public.notifications (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
 ticket_id uuid REFERENCES public.tickets(id) ON DELETE CASCADE,
 message text NOT NULL,
 is_read boolean NOT NULL DEFAULT false,
 created_at timestamptz NOT NULL DEFAULT now()
);
